from brain_final import work_bot
botngu = work_bot()


# botngu.test()
botngu.login()
botngu.word_ai()

botngu.set_article_length()
botngu.sub_key_words()
botngu.click_close()