Để cài đặt thư viện cho ứng dụng, vui lòng chạy file setup.bat tại thư mục soucre_code.
Chương trình này là chương trình cung cấp bài tập dựa trên lỗi bạn đã mắc phải.
Khi mở chương trình lên hãy nhấn chọn tệp tin ở phần tệp tin chứa lỗi ngữ pháp.
sau đó hãy chọn file cssv chứa lỗi ngữ pháp của bạn. Tại thư mục data trong thư mục soucre_code sẽ có những file csv chứa các lỗi để bạn chạy thử.
Sau đó hãy chọn số lượng câu bài tập mà bạn muốn làm. Bạn hãy điền bằng chữ. nếu không chương trình sẽ báo lỗi bắt nhập lại.
Sau đó bạn hãy chọn chỗ lưu bài tập mà bạn muốn.
Hãy nhấn "Tạo bài" để chương trình có thể tạo bài cho bạn. Bạn có thể tạo lại bài khác bằng cách nhấn "Tạo bài" một lần nữa.
Bài tập được tạo đã có đáp án sẵn. Hãy tự giác làm và so sánh với kết quả bên dưới.
Nếu bạn cảm thấy đủ. Hãy nhấn "Thoát" để thoát.
Lưu ý: Tên của file Bài tập đã được mặc định từ trước nên nếu bạn muốn gữi lại file bài tập cũ để ôn tập, hãy sửa tên file.
Nếu muốn tự tạo một file csv lỗi mới hãy dựa theo đúng cấu trúc đã được cung cấp ở file mẫu để sử dụng. Vui lòng không thêm bất kì một cột dư nào. Điều đó có thể gây ra lỗi.